const express = require('express');
const router = express.router();

router.post('./post',(req,res)=>{
    res.send('Post Criado');
})

module.exports = router; 